// src/pages/schedules/ExportSchedulePage.jsx
import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ChevronLeft, Download } from 'lucide-react';
import toast from 'react-hot-toast';

import Button from '../../components/common/Button';
import { scheduleApi } from '../../api/scheduleApi';

const INPUT = 'w-full border border-surface-border rounded-lg px-3 py-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-brand-500';
const LABEL = 'block text-sm font-medium text-ink mb-1.5';

export default function ExportSchedulePage() {
  const navigate = useNavigate();
  const [exporting, setExporting] = useState(false);

  // Bộ lọc
  const [filters, setFilters] = useState({
    schedule_type: '',
    semester_id: '',
    course_id: '',
    lecturer_id: '',
    room: '',
    start_date: '',
    end_date: ''
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFilters(prev => ({ ...prev, [name]: value }));
  };

  const handleExport = async (e) => {
    e.preventDefault();
    setExporting(true);

    try {
      // Loại bỏ các trường rỗng
      const params = Object.fromEntries(
        Object.entries(filters).filter(([_, v]) => v.trim() !== '')
      );

      const response = await scheduleApi.export(params);
      
      // Tạo URL từ Blob và tải xuống file
      const url = window.URL.createObjectURL(new Blob([response.data]));
      const link = document.createElement('a');
      link.href = url;
      link.setAttribute('download', 'thoi_khoa_bieu.xlsx');
      document.body.appendChild(link);
      link.click();
      link.remove();
      toast.success('Xuất file thành công!');
    } catch (err) {
      toast.error('Lỗi khi tải file. Vui lòng thử lại.');
      console.error(err);
    } finally {
      setExporting(false);
    }
  };

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <Button variant="ghost" size="sm" icon={<ChevronLeft size={15} />} onClick={() => navigate('/schedules')}>
        Quay lại
      </Button>

      <div className="card p-6">
        <h1 className="text-xl font-bold text-ink mb-2">Xuất Thời Khóa Biểu (Excel)</h1>
        <p className="text-sm text-ink-muted mb-6">
          Điền các thông tin bên dưới để lọc danh sách cần xuất. Nếu để trống tất cả, hệ thống sẽ tải toàn bộ thời khóa biểu của trường.
        </p>
        
        <form onSubmit={handleExport} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            <div className="md:col-span-2">
              <label className={LABEL}>Loại lịch</label>
              <select name="schedule_type" value={filters.schedule_type} onChange={handleChange} className={INPUT}>
                <option value="">-- Tất cả (Cả 3 loại) --</option>
                <option value="1">Lịch học</option>
                <option value="2">Lịch thi</option>
                <option value="3">Lịch thi lại</option>
              </select>
            </div>

            <div>
              <label className={LABEL}>Học kỳ</label>
              <input type="text" name="semester_id" value={filters.semester_id} onChange={handleChange} className={INPUT} placeholder="Nhập mã học kỳ (VD: HK1_2026)" />
            </div>

            <div>
              <label className={LABEL}>Mã môn học</label>
              <input type="text" name="course_id" value={filters.course_id} onChange={handleChange} className={INPUT} placeholder="Nhập mã học phần" />
            </div>

            <div>
              <label className={LABEL}>Giảng viên</label>
              <input type="text" name="lecturer_id" value={filters.lecturer_id} onChange={handleChange} className={INPUT} placeholder="Nhập mã/tên giảng viên" />
            </div>

            <div>
              <label className={LABEL}>Phòng học / Tòa nhà</label>
              <input type="text" name="room" value={filters.room} onChange={handleChange} className={INPUT} placeholder="VD: A1-101" />
            </div>

            <div>
              <label className={LABEL}>Từ ngày (Ngày học/thi)</label>
              <input type="date" name="start_date" value={filters.start_date} onChange={handleChange} className={INPUT} />
            </div>

            <div>
              <label className={LABEL}>Đến ngày (Ngày học/thi)</label>
              <input type="date" name="end_date" value={filters.end_date} onChange={handleChange} className={INPUT} />
            </div>

          </div>

          <div className="flex justify-end pt-4 border-t border-surface-border">
            <Button type="submit" disabled={exporting} icon={<Download size={16} />}>
              {exporting ? 'Đang chuẩn bị file...' : 'Tải Xuống Excel'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
