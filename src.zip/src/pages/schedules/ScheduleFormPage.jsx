// src/pages/schedules/ScheduleFormPage.jsx
import { useState, useEffect } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { ChevronLeft, Save } from 'lucide-react';
import toast from 'react-hot-toast';

import Button from '../../components/common/Button';
import { scheduleApi } from '../../api/scheduleApi';

const INPUT = 'w-full border border-surface-border rounded-lg px-3 py-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-brand-500';
const LABEL = 'block text-sm font-medium text-ink mb-1.5';

export default function ScheduleFormPage() {
  const navigate = useNavigate();
  const { id } = useParams();
  const isEdit = Boolean(id);

  const [loading, setLoading] = useState(false);
  const [saving, setSaving] = useState(false);

  // Form State
  const [scheduleType, setScheduleType] = useState('1'); // Mặc định Lịch học
  const [formData, setFormData] = useState({
    semester_id: '',
    course_id: '',
    day_of_week: '',
    start_period: '',
    end_period: '',
    start_time: '',
    end_time: '',
    event_date: '',
    room: '',
    building: '',
    lecturer_id: '',
    week_start: '',
    week_end: '',
    notes: ''
  });

  useEffect(() => {
    if (isEdit) {
      fetchDetail();
    }
  }, [id]);

  const fetchDetail = async () => {
    setLoading(true);
    try {
      const res = await scheduleApi.getDetail(id);
      const data = res?.data?.data || res?.data || res;
      setScheduleType(String(data.schedule_type || 1));
      setFormData({
        semester_id: data.semester_id || '',
        course_id: data.course_id || '',
        day_of_week: data.day_of_week || '',
        start_period: data.start_period || '',
        end_period: data.end_period || '',
        start_time: data.start_time || '',
        end_time: data.end_time || '',
        event_date: data.event_date ? new Date(data.event_date).toISOString().split('T')[0] : '',
        room: data.room || '',
        building: data.building || '',
        lecturer_id: data.lecturer_id || '',
        week_start: data.week_start || '',
        week_end: data.week_end || '',
        notes: data.notes || ''
      });
    } catch (err) {
      toast.error('Không tải được thông tin lịch');
      navigate('/schedules');
    } finally {
      setLoading(false);
    }
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const validateForm = () => {
    const type = parseInt(scheduleType);
    if (!formData.semester_id) return 'Vui lòng nhập Học kỳ';
    if (!formData.course_id) return 'Vui lòng nhập Mã môn học';
    if (!formData.room) return 'Vui lòng nhập Phòng học';

    if (type === 1) { // Lịch học
      if (!formData.day_of_week) return 'Vui lòng chọn Thứ';
      const dow = parseInt(formData.day_of_week);
      if (dow < 2 || dow > 8) return 'Thứ phải từ 2 đến 8';

      if (!formData.start_period || !formData.end_period) return 'Vui lòng nhập Tiết bắt đầu và Tiết kết thúc';
      if (parseInt(formData.start_period) > parseInt(formData.end_period)) return 'Tiết bắt đầu không được lớn hơn Tiết kết thúc';
      
      if (formData.week_start && formData.week_end) {
        if (parseInt(formData.week_start) > parseInt(formData.week_end)) return 'Tuần bắt đầu không được lớn hơn Tuần kết thúc';
      }
    } else { // Lịch thi, Lịch thi lại
      if (!formData.event_date) return 'Vui lòng chọn Ngày thi';
      if (!formData.start_time) return 'Vui lòng nhập Giờ bắt đầu';
      
      const eventDate = new Date(formData.event_date);
      const today = new Date();
      today.setHours(0, 0, 0, 0);
      if (eventDate < today && !isEdit) { // Chỉ check ngày trong tương lai khi tạo mới
        return 'Ngày thi phải lớn hơn hoặc bằng ngày hiện tại';
      }
    }
    return null;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    const errorMsg = validateForm();
    if (errorMsg) {
      toast.error(errorMsg);
      return;
    }

    setSaving(true);
    const payload = {
      ...formData,
      schedule_type: parseInt(scheduleType)
    };

    // Chuẩn hóa dữ liệu theo loại lịch
    if (payload.schedule_type !== 1) {
      payload.day_of_week = null;
      payload.start_period = null;
      payload.end_period = null;
      payload.week_start = null;
      payload.week_end = null;
    } else {
      payload.event_date = null;
    }

    try {
      if (isEdit) {
        await scheduleApi.update(id, payload);
        toast.success('Cập nhật thành công');
      } else {
        await scheduleApi.create(payload);
        toast.success('Tạo mới thành công');
      }
      navigate('/schedules');
    } catch (err) {
      toast.error(err?.response?.data?.message || 'Có lỗi xảy ra khi lưu');
    } finally {
      setSaving(false);
    }
  };

  if (loading) return <div className="text-center py-20 text-ink-subtle">Đang tải...</div>;

  const isStudy = scheduleType === '1';

  return (
    <div className="max-w-3xl mx-auto space-y-6">
      <Button variant="ghost" size="sm" icon={<ChevronLeft size={15} />} onClick={() => navigate('/schedules')}>
        Quay lại
      </Button>

      <div className="card p-6">
        <h1 className="text-xl font-bold text-ink mb-6">{isEdit ? 'Chỉnh sửa Thời khóa biểu' : 'Thêm mới Thời khóa biểu'}</h1>
        
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            
            {/* Trường chung */}
            <div className="md:col-span-2">
              <label className={LABEL}>Loại lịch</label>
              <select value={scheduleType} onChange={e => setScheduleType(e.target.value)} className={INPUT} disabled={isEdit}>
                <option value="1">Lịch học</option>
                <option value="2">Lịch thi</option>
                <option value="3">Lịch thi lại</option>
              </select>
            </div>

            <div>
              <label className={LABEL}>Học kỳ <span className="text-red-500">*</span></label>
              <input type="text" name="semester_id" value={formData.semester_id} onChange={handleChange} className={INPUT} placeholder="Ví dụ: HK1_2026" required />
            </div>

            <div>
              <label className={LABEL}>Mã môn học <span className="text-red-500">*</span></label>
              <input type="text" name="course_id" value={formData.course_id} onChange={handleChange} className={INPUT} placeholder="Ví dụ: IT101" required />
            </div>

            {/* Các trường theo Loại lịch */}
            {isStudy ? (
              <>
                <div>
                  <label className={LABEL}>Giảng viên</label>
                  <input type="text" name="lecturer_id" value={formData.lecturer_id} onChange={handleChange} className={INPUT} placeholder="Mã GV" />
                </div>
                <div>
                  <label className={LABEL}>Thứ <span className="text-red-500">*</span></label>
                  <select name="day_of_week" value={formData.day_of_week} onChange={handleChange} className={INPUT} required>
                    <option value="">-- Chọn thứ --</option>
                    {[2,3,4,5,6,7,8].map(d => <option key={d} value={d}>{d === 8 ? 'Chủ nhật' : `Thứ ${d}`}</option>)}
                  </select>
                </div>
                <div>
                  <label className={LABEL}>Tiết bắt đầu <span className="text-red-500">*</span></label>
                  <input type="number" name="start_period" value={formData.start_period} onChange={handleChange} className={INPUT} min="1" max="15" required />
                </div>
                <div>
                  <label className={LABEL}>Tiết kết thúc <span className="text-red-500">*</span></label>
                  <input type="number" name="end_period" value={formData.end_period} onChange={handleChange} className={INPUT} min="1" max="15" required />
                </div>
                <div>
                  <label className={LABEL}>Tuần bắt đầu</label>
                  <input type="number" name="week_start" value={formData.week_start} onChange={handleChange} className={INPUT} min="1" />
                </div>
                <div>
                  <label className={LABEL}>Tuần kết thúc</label>
                  <input type="number" name="week_end" value={formData.week_end} onChange={handleChange} className={INPUT} min="1" />
                </div>
              </>
            ) : (
              <>
                <div>
                  <label className={LABEL}>Ngày thi <span className="text-red-500">*</span></label>
                  <input type="date" name="event_date" value={formData.event_date} onChange={handleChange} className={INPUT} required />
                </div>
              </>
            )}

            {/* Giờ bắt đầu & kết thúc */}
            <div>
              <label className={LABEL}>Giờ bắt đầu {(!isStudy) && <span className="text-red-500">*</span>}</label>
              <input type="time" name="start_time" value={formData.start_time} onChange={handleChange} className={INPUT} required={!isStudy} />
            </div>
            <div>
              <label className={LABEL}>Giờ kết thúc</label>
              <input type="time" name="end_time" value={formData.end_time} onChange={handleChange} className={INPUT} />
            </div>

            {/* Phòng & Tòa nhà */}
            <div>
              <label className={LABEL}>Phòng học/thi <span className="text-red-500">*</span></label>
              <input type="text" name="room" value={formData.room} onChange={handleChange} className={INPUT} placeholder="Ví dụ: A1-101" required />
            </div>
            <div>
              <label className={LABEL}>Tòa nhà</label>
              <input type="text" name="building" value={formData.building} onChange={handleChange} className={INPUT} placeholder="Ví dụ: A1" />
            </div>

            {/* Ghi chú */}
            <div className="md:col-span-2">
              <label className={LABEL}>Ghi chú</label>
              <textarea name="notes" value={formData.notes} onChange={handleChange} className={`${INPUT} h-24 resize-none`} placeholder="Ghi chú thêm..."></textarea>
            </div>

          </div>

          <div className="flex justify-end pt-4 border-t border-surface-border">
            <Button type="submit" disabled={saving} icon={<Save size={16} />}>
              {saving ? 'Đang lưu...' : 'Lưu lại'}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
