// src/pages/schedules/ScheduleListPage.jsx
import { useState, useMemo, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { createColumnHelper } from '@tanstack/react-table';
import { Search, Download, Upload, Eye, Edit, Trash2, CalendarDays } from 'lucide-react';
import toast from 'react-hot-toast';

import DataTable  from '../../components/common/DataTable';
import Pagination from '../../components/common/Pagination';
import Badge      from '../../components/common/Badge';
import Button     from '../../components/common/Button';
import EmptyState from '../../components/common/EmptyState';
import { scheduleApi } from '../../api/scheduleApi';

const PAGE_SIZE = 10;
const col = createColumnHelper();
const SELECT = 'border border-surface-border rounded-lg px-3 py-2 text-sm bg-white focus:outline-none focus:ring-2 focus:ring-brand-500';

const SCHEDULE_TYPES = [
  { value: 1, label: 'Lịch học' },
  { value: 2, label: 'Lịch thi' },
  { value: 3, label: 'Lịch thi lại' }
];

export default function ScheduleListPage() {
  const navigate = useNavigate();

  const [schedules, setSchedules] = useState([]);
  const [totalElements, setTotalElements] = useState(0);
  const [loading, setLoading] = useState(false);

  // Filters
  const [search, setSearch] = useState('');
  const [query, setQuery] = useState('');
  const [scheduleType, setScheduleType] = useState('');
  const [semester, setSemester] = useState(''); // Thường lấy từ bảng SEMESTER, tạm để input/dropdown đơn giản
  
  const [page, setPage] = useState(0);
  const timer = useRef(null);

  function handleSearch(val) {
    setSearch(val);
    clearTimeout(timer.current);
    timer.current = setTimeout(() => {
      setQuery(val);
      setPage(0);
    }, 400);
  }

  useEffect(() => () => clearTimeout(timer.current), []);

  useEffect(() => {
    setPage(0);
  }, [scheduleType, semester]);

  const fetchSchedules = async () => {
    setLoading(true);
    try {
      const params = {
        search: query || undefined,
        schedule_type: scheduleType || undefined,
        semester_id: semester || undefined,
        page: page,
        size: PAGE_SIZE
      };

      const response = await scheduleApi.getList(params);
      const pageData = response?.data?.data || response?.data || response;

      if (pageData && pageData.content) {
        setSchedules(pageData.content);
        setTotalElements(pageData.totalElements || pageData.content.length);
      } else if (Array.isArray(pageData)) {
        // Fallback in case API returns flat array
        setSchedules(pageData.slice(page * PAGE_SIZE, (page + 1) * PAGE_SIZE));
        setTotalElements(pageData.length);
      } else {
        setSchedules([]);
        setTotalElements(0);
      }
    } catch (error) {
      console.error('Lỗi khi fetch TKB: ', error);
      setSchedules([]);
      setTotalElements(0);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchSchedules();
  }, [query, scheduleType, semester, page]);

  const handleDelete = async (id) => {
    if (!window.confirm('Bạn có chắc chắn muốn xóa thời khóa biểu này?')) return;
    try {
      await scheduleApi.delete(id);
      toast.success('Xóa thành công!');
      fetchSchedules();
    } catch (err) {
      toast.error('Lỗi khi xóa!');
    }
  };

  const columns = useMemo(() => [
    col.accessor('schedule_id', {
      header: 'ID',
      cell: i => <span className="font-mono text-xs text-ink-subtle">{i.getValue() || i.row.original.id}</span>,
    }),
    col.accessor('schedule_type', {
      header: 'Loại lịch',
      cell: i => {
        const type = parseInt(i.getValue());
        if (type === 1) return <span className="font-medium text-ink">Lịch học</span>;
        if (type === 2) return <Badge variant="warning">LỊCH THI</Badge>;
        if (type === 3) return <Badge variant="error">LỊCH THI LẠI</Badge>;
        return <span>—</span>;
      },
    }),
    col.accessor('courseCode', { // Có thể backend trả về courseCode, courseName đã join
      header: 'Môn học',
      cell: i => <span className="font-medium">{i.getValue() || i.row.original.course_id || '—'}</span>,
    }),
    col.accessor('semester_id', { 
      header: 'Học kỳ',
      cell: i => <span>{i.getValue() || '—'}</span>,
    }),
    col.accessor('event_date', {
      header: 'Ngày',
      cell: i => <span>{i.getValue() ? new Date(i.getValue()).toLocaleDateString('vi-VN') : '—'}</span>,
    }),
    col.accessor('day_of_week', {
      header: 'Thứ',
      cell: i => {
        const v = i.getValue();
        return v ? (v === 8 ? 'CN' : `Thứ ${v}`) : '—';
      },
    }),
    col.accessor('periods', {
      id: 'periods',
      header: 'Tiết học',
      cell: i => {
        const start = i.row.original.start_period;
        const end = i.row.original.end_period;
        if (start && end) return <span>{start} - {end}</span>;
        return <span>—</span>;
      }
    }),
    col.accessor('room', {
      header: 'Phòng',
      cell: i => <span className="font-mono bg-surface-muted px-1.5 py-0.5 rounded text-xs">{i.getValue() || '—'}</span>,
    }),
    col.accessor('lecturerName', {
      header: 'Giảng viên',
      cell: i => <span>{i.getValue() || i.row.original.lecturer_id || '—'}</span>,
    }),
    col.accessor('notes', {
      header: 'Ghi chú',
      cell: i => <span className="text-ink-muted truncate max-w-[150px] inline-block" title={i.getValue()}>{i.getValue() || '—'}</span>,
    }),
    col.display({
      id: 'actions', 
      header: '',
      cell: i => {
        const id = i.row.original.schedule_id || i.row.original.id;
        return (
          <div className="flex items-center gap-1">
            <button
              title="Chỉnh sửa"
              onClick={() => navigate(`/schedules/${id}/edit`)}
              className="p-1.5 rounded-lg hover:bg-surface-hover text-ink-subtle hover:text-blue-600 transition-colors"
            >
              <Edit size={16} />
            </button>
            <button
              title="Xóa"
              onClick={() => handleDelete(id)}
              className="p-1.5 rounded-lg hover:bg-surface-hover text-ink-subtle hover:text-red-600 transition-colors"
            >
              <Trash2 size={16} />
            </button>
          </div>
        );
      },
    }),
  ], [navigate]);

  return (
    <div className="space-y-4 max-w-[1400px]">
      {/* Toolbar */}
      <div className="flex items-center justify-between gap-3 flex-wrap">
        <div className="flex items-center gap-2 flex-wrap">
          <div className="relative">
            <Search size={16} className="absolute left-3 top-1/2 -translate-y-1/2 text-ink-subtle" />
            <input
              value={search}
              onChange={e => handleSearch(e.target.value)}
              placeholder="Tìm môn học, phòng..."
              className="pl-9 pr-4 py-2 text-sm border border-surface-border rounded-lg w-60 focus:outline-none focus:ring-2 focus:ring-brand-500"
            />
          </div>
          <select value={scheduleType} onChange={e => setScheduleType(e.target.value)} className={SELECT}>
            <option value="">Tất cả loại lịch</option>
            {SCHEDULE_TYPES.map(t => <option key={t.value} value={t.value}>{t.label}</option>)}
          </select>
          {/* Có thể thêm dropdown Học kỳ ở đây */}
          <input 
            type="text" 
            placeholder="Mã Học kỳ..." 
            value={semester} 
            onChange={e => setSemester(e.target.value)} 
            className={`${SELECT} w-32`}
          />
        </div>

        <div className="flex items-center gap-2">
          <Button variant="outlined" size="sm" icon={<Download size={15}/>} onClick={() => navigate('/schedules/export')}>
            Export Excel
          </Button>
          <Button size="sm" icon={<Upload size={15}/>} onClick={() => navigate('/schedules/import')}>
            Import TKB
          </Button>
          <Button size="sm" onClick={() => navigate('/schedules/create')}>
            Thêm thủ công
          </Button>
        </div>
      </div>

      {/* Bảng dữ liệu */}
      <div className="card overflow-hidden">
        {loading ? (
          <div className="flex flex-col items-center justify-center py-20 bg-white">
            <div className="w-8 h-8 border-4 border-brand-500 border-t-transparent rounded-full animate-spin"></div>
            <p className="text-sm text-ink-subtle mt-4">Đang tải danh sách thời khóa biểu...</p>
          </div>
        ) : (
          <>
            <DataTable
              columns={columns}
              data={schedules}
              emptyState={
                <EmptyState
                  icon={<CalendarDays size={40} className="text-ink-subtle" />}
                  title="Chưa có thời khóa biểu"
                  message="Không tìm thấy lịch học/thi nào phù hợp với điều kiện tìm kiếm."
                />
              }
            />
            {totalElements > 0 && (
              <div className="border-t border-surface-border px-4">
                <Pagination 
                  page={page} 
                  total={totalElements} 
                  pageSize={PAGE_SIZE} 
                  onChange={setPage} 
                />
              </div>
            )}
          </>
        )}
      </div>
    </div>
  );
}
