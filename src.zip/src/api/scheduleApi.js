import client from './axiosClient';

export const scheduleApi = {
  // Lấy danh sách TKB (có phân trang và bộ lọc)
  getList: (params) => {
    return client.get('/admin/schedules', { params });
  },

  // Xem chi tiết TKB
  getDetail: (id) => {
    return client.get(`/admin/schedules/${id}`);
  },

  // Tạo mới TKB (thủ công)
  create: (data) => {
    return client.post('/admin/schedules', data);
  },

  // Cập nhật TKB
  update: (id, data) => {
    return client.put(`/admin/schedules/${id}`, data);
  },

  // Xóa TKB
  delete: (id) => {
    return client.delete(`/admin/schedules/${id}`);
  },

  // Export TKB ra Excel
  export: (params) => {
    return client.get('/admin/schedules/export', { 
      params,
      responseType: 'blob' // Xử lý file download
    });
  },

  // Import TKB từ Excel (Form Data)
  importExcel: (file, scheduleType, overwrite = false, onProgress) => {
    const formData = new FormData();
    formData.append('file', file);
    formData.append('schedule_type', scheduleType);
    formData.append('overwrite', String(overwrite));

    return client.post('/admin/import/schedules', formData, {
      headers: { 'Content-Type': 'multipart/form-data' },
      onUploadProgress: (e) => {
        if (onProgress && e.total) {
          onProgress(Math.round((e.loaded * 100) / e.total));
        }
      },
    });
  }
};
